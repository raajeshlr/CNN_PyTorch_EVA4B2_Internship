Achieve 99.4% validation accuracy for MNIST dataset with the following constraints:

1. Less than or equal to 15 Epochs
2. Less than 10000 Parameters